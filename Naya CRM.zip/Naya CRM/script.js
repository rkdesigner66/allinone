$(document).ready(function(){
    $('.dropdown-item').click(function(){
        $(this).next('.dropdown_items').toggle(); // or .slideToggle() for sliding effect
    });
});


// Select all radio buttons
const priorityOptions = document.querySelectorAll('.priority-option input');

priorityOptions.forEach(option => {
    option.addEventListener('click', function () {
        // Remove the 'checked' class from all options
        priorityOptions.forEach(opt => {
            opt.parentElement.classList.remove('checked');
        });
        // Add the 'checked' class to the clicked option
        this.parentElement.classList.add('checked');
    });
});

// Add double-click event to change color
priorityOptions.forEach(option => {
    option.addEventListener('dblclick', function () {
        // Manually toggle the checked state
        this.checked = !this.checked;
        // Trigger the click event
        this.dispatchEvent(new Event('click'));
    });
});

$('#toggleSidebarBtn').click(function() {
    $('.main_sidebar_div').toggleClass('collapsed');
    $('.sidebar2').toggleClass('collapsed2');
  });
  