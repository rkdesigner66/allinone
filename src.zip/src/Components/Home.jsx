import React from 'react'

const Home = () => {
  return (
    <div className='container p-5 m-5' id='home_custom'>
      <h1 className='text-center'>Welcome to All In On Convertor</h1>
      <p className='text-center'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ducimus, officia. Reprehenderit, adipisci neque rem voluptatem incidunt facere ab perspiciatis enim culpa blanditiis repellat iure recusandae quibusdam reiciendis ipsam dolor aliquid.</p>
<a href='/convertor' className='btn btn-info'>Text Convertor</a>
<a href='/image-comparison' className='btn btn-info' >Image Comparsion</a>
    </div>
  )
}

export default Home
